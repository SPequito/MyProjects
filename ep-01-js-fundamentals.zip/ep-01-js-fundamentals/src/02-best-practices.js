/**
 * Best Practices
 */

/**
 * Obtain user details
 */
//FIXME: there is an issue with this implementation, please fix it
exports.getUser = function() {
    myObject = {
        name: 'Pedro',
        email: 'pedro.antoninho@academiadecodigo.org'
    };

    return myObject;
};

/**
 * Convert String to Number
 */
exports.parseNumber = function(num) {
    return parseInt(num);
};

/**
 * Tests for equality 
 */
exports.isEqual = function(val1, val2) {
};
