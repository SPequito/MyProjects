/**
 * logical OR
 */
exports.or = function(a, b) {
};

/**
 * logical AND
 */
exports.and = function(a, b) {
};
